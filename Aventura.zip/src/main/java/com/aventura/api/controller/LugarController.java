package com.aventura.api.controller;

import com.aventura.api.dto.LugarDTO;
import com.aventura.api.service.LugarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/lugares")
@CrossOrigin(origins = "*")
public class LugarController {

    @Autowired
    private LugarService lugarService;

    @GetMapping
    public List<LugarDTO> getAllLugares() {
        return lugarService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<LugarDTO> getLugarById(@PathVariable String id) {
        return lugarService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<LugarDTO> createLugar(@RequestBody LugarDTO dto) {
        LugarDTO creado = lugarService.save(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(creado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLugar(@PathVariable String id) {
        lugarService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
