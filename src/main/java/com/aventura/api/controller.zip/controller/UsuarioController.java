package com.aventura.api.controller;

import com.aventura.api.dto.UsuarioDTO;
import com.aventura.api.entity.Usuario;
import com.aventura.api.mapper.UsuarioMapper;
import com.aventura.api.service.impl.UsuarioServiceImpl;
import com.aventura.api.service1.UsuarioService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("usuarios")
@CrossOrigin(origins = "*")
public class UsuarioController {

	private final UsuarioService usuarioService;
	private final UsuarioMapper usuarioMapper;

	public UsuarioController(UsuarioService usuarioService, UsuarioMapper usuarioMapper) {
		this.usuarioService = usuarioService;
		this.usuarioMapper = usuarioMapper;
	}

	@GetMapping
	public List<UsuarioDTO> getAllUsuarios() {
		return usuarioService.findAll().stream().map(usuarioMapper::toDTO).toList();
	}
	
    @GetMapping("/{id}")
    public Optional<Usuario> getUsuarioById(@PathVariable UUID id) {
        return usuarioService.findById(id);
    }

    @PostMapping("/registrar")
    public ResponseEntity<UsuarioDTO> createUsuario(@RequestBody UsuarioDTO usuarioDTO) {
    	UsuarioDTO nuevoUsuario = usuarioService.crearUsuario(usuarioDTO);
        return  ResponseEntity.status(HttpStatus.CREATED).body(nuevoUsuario);
    }

    @DeleteMapping("/{id}")
    public void deleteUsuario(@PathVariable UUID id) {
        usuarioService.deleteById(id);
    }
}
