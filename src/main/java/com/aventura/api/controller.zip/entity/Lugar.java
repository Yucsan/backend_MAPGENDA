package com.aventura.api.entity;

import jakarta.persistence.*;
import lombok.*;
import java.util.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "lugar")
public class Lugar {

    @Id
    private String id;

    private String nombre;
    private Double latitud;
    private Double longitud;
    private String direccion;
    private String tipo;
    private BigDecimal calificacion;
    private String fotoUrl;
    private Boolean abiertoAhora;
    private Integer duracionEstimadaMinutos;
}