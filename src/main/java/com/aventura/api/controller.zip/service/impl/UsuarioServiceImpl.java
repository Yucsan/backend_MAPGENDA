package com.aventura.api.service.impl;

import com.aventura.api.dto.UsuarioDTO;
import com.aventura.api.entity.Usuario;
import com.aventura.api.mapper.UsuarioMapper;
import com.aventura.api.repository.UsuarioRepository;
import com.aventura.api.service1.UsuarioService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class UsuarioServiceImpl implements UsuarioService{

    @Autowired
    private UsuarioRepository usuarioRepository;
    
    @Autowired
    private UsuarioMapper usuarioMapper;

    public List<Usuario> findAll() {
        return usuarioRepository.findAll();
    }

    public Optional<Usuario> findById(UUID id) {
        return usuarioRepository.findById(id);
    }

    public Usuario save(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }
    

    // Crear usuario desde DTO
    public UsuarioDTO crearUsuario(UsuarioDTO dto) {
        Usuario entity = usuarioMapper.toEntity(dto);
        entity.setFechaRegistro(new Timestamp(System.currentTimeMillis()));
        Usuario guardado = usuarioRepository.save(entity);
        return usuarioMapper.toDTO(guardado);
    }


    public void deleteById(UUID id) {
        usuarioRepository.deleteById(id);
    }
}
